const Person = require("./person");

result.Person = Person;